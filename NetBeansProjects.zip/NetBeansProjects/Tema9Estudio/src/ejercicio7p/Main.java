package ejercicio7p;

/*Crea un método que, dado un nombre de fichero y una palabra, 
genere un fichero nuevo igual pero en el que no aparezca la palabra dada. 
Si el fichero de entrada se llama fichero.txt, el nuevo fichero se llamará fichero_2.txt. */

public class Main {

        public static void main(String[] args) {
            
            GestorFichero gf=new GestorFichero();
            
            gf.leerArchivo("prueba1.txt", "primer");
            
        }

}
