package ejercicio8p;

/*Crea un programa que dado un fichero genere otro fichero cifrado usando el cifrado César. 
También tendrá que ser capaz de descifrar el fichero cifrado.*/

public class Main {

        public static void main(String[] args) {
            // TODO code application logic here
        }

}
