package ejercicio6p;

/*Crea un método que permita buscar palabras en un fichero de texto.
Se debe mostrar el número de ocurrencias de dicha palabra. Usa un buffer para la lectura.*/

public class Main {

        public static void main(String[] args) {
            
            GestorFichero gf=new GestorFichero();
            
            gf.leerArchivo("prueba1.txt", "primer");
            
        }

}
