package ejercicio3p;

/*Escribe un programa que copie el contenido de un archivo de texto a otro.*/

public class Main {

        public static void main(String[] args) {
            // TODO code application logic here
        }

}
