package ejercicio1p;

/*Escribe un programa que guarde en un fichero con nombre primos.txt 
los números primos que hay entre 1 y 500. 
(Busca en Wikipedia "Criba de Eratóstenes)*/

import java.util.Math;

public class Main {

        public static void main(String[] args) {
            // TODO code application logic here
            int hola ;
            int adios=Math.
        }

}
