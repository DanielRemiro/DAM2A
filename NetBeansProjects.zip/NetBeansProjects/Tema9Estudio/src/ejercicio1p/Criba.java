package ejercicio1p;



public class Criba {

    
    
}
