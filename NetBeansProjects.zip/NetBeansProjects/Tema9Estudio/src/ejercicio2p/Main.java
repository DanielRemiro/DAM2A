package ejercicio2p;

/*Realiza un programa que lea el fichero creado en el ejercicio anterior
y que muestre los números por pantalla.*/

public class Main {

        public static void main(String[] args) {
            // TODO code application logic here
        }

}
