package ejercicio4p;

/*Escribe un método que reciba el nombre de un archivo y un entero.
Se creará el archivo y se escribirá n líneas, siendo n el número pasado en el método.
En cada línea se escribirá “Esta línea es la n”, sustituyendo n por el número de línea.
Hazlo con un buffer para que sea más eficiente.*/

public class Main {

        public static void main(String[] args) {
            // TODO code application logic here
        }

}
