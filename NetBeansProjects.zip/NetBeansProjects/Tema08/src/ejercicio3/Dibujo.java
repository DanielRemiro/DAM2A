
package ejercicio3;

/**
 *
 * @author dremi
 */
public class Dibujo {
    
    public static String cero(){
        
        return " ";
        
    }
    
    public static String uno(){
    
        return "o";
        
    }
    
    public static String dos(){
        
        return "oo";
        
    }
    
    public static String tres(){
        
        return "ooo";
        
    }
    
    public static String cuatro(){
        
        return "oo\noo";
        
    }
    
    public static String cinco(){
        
        return "o o\n o\no o";
        
    }
    
    public static String seis(){
    
        return "o o\no o\no o";
        
    }
    
}
