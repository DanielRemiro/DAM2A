package ejercicio12p;

/**
 *
 * @author dremi
 */
public class Menu {
    
    public static void Menu(){
    
        System.out.println("--------------------");
        System.out.println("1. Alta material.");
        System.out.println("2. Baja material.");
        System.out.println("3. Alta usuario.");
        System.out.println("4. Prestar material.");
        System.out.println("5. Salir.");
        System.out.println("--------------------");
        
    }
    
}
