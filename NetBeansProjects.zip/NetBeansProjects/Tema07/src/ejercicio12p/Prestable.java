package ejercicio12p;

/**
 *
 * @author dremi
 */
public interface Prestable {
    
    void prestar ()throws Excepcion;
    void devolver();
    void estaPrestado();
    
}
