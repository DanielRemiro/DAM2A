package ejercicio16p;

/**
 *
 * @author dremi
 */
public class Empleado {

    protected double sueldo;
    protected String nombre;
        
    public Empleado(double sueldo, String nombre){
        
        this.sueldo=sueldo;
        this.nombre=nombre;
        
    }
    
    
    
}
