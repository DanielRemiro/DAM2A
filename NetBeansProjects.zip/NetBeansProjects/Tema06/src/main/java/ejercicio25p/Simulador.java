package ejercicio25p;

/**
 *
 * @author dremi
 */

import java.util.Scanner;

public class Simulador {
    
    
    void simulacionMovimiento(Vehiculo vehiculo){
        
        vehiculo.preguntarMover();
        
    }
        
    
    
    
}
