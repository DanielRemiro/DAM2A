package ejercicio25p;

/**
 *
 * @author dremi
 */
public interface Vehiculo {
    
    void preguntarMover();
    void mover();
    
}
                            