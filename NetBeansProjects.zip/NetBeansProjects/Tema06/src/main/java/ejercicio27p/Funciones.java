package ejercicio27p;

/**
 *
 * @author dremi
 */
public interface Funciones {
    
    void interfaz();
    void elegir();
    void escribir();
    
}
