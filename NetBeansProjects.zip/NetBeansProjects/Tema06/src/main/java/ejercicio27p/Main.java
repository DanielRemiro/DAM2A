package ejercicio27p;

/**
 *
 * @author dremi
 */
public class Main {
    
    public static void main(String args[]){
        
        Movil movil = new Movil();
        
        movil.interfaz();
        
    }
    
}
