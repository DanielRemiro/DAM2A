package ejercicio14p;

/*Crea un programa que, dada una posición y una distancia en metros, 
muestre los aparcabicis que haya a la redonda entre tu posición y la distancia especificada.
Para calcular la distancia entre dos puntos geométricos, 
puedes usar la fórmula que se encuentran en la siguiente página:  
https://www.omnicalculator.com/es/otros/calculadora-latitud-longitud-distancia

Primero se mostrarán los más cercanos a tu posición. 
Para cada aparcabicis, tendrá que aparecer la información de la calle donde se encuentra,
el número de anclajes y el número de plazas, así como la distancia entre tú y el aparcabicis.
Añade otra funcionalidad, de manera que, al escribir el nombre de un lugar 
(calle, instituto, polideportivo…) encuentre los aparcabicis que hay en dicho lugar, las plazas,
si es accesible o no y la distancia entre posición y los aparcabicis encontrados.

(Aprovecha para investigar en la página de datos abiertos del ayuntamiento, 
o de cualquier otra fuente, para ver si hay datos de algo que te interese para crear algún pequeño 
programa).
*/

public class Main {

        public static void main(String[] args) {
            // TODO code application logic here
        }

}
