package menup;



public class Menu {

    
    public static void Menu(){
        
        System.out.println("--------------------------");
        System.out.println("1.Anadir coche a la flota.");
        System.out.println("2.Registrar viaje.");
        System.out.println("3.Historial de viajes.");
        System.out.println("0.Salir");
        System.out.println("--------------------------");
        
    }
    
}
